# Secure University Management Portal

Node.js + Express + MongoDB (Mongoose) REST API with JWT authentication, bcrypt hashing, role-based access
(Admin / Teacher / Student), attendance, marks, notices with file upload, and a browser dashboard.

## Run it (Windows)
1. Install Node.js 18+ and start MongoDB (local service) **or** put a MongoDB Atlas URL in `backend/.env` after step 2.
2. Double-click **`setup.bat`** (or run `setup.ps1`). It installs packages, creates `backend/.env` with a random JWT secret,
   seeds demo data and opens http://localhost:5000.

Manual: `cd backend && npm install && node scripts/make-env.js && npm run seed && npm start`

## Demo accounts (after seeding)
| Role | Email | Password |
|---|---|---|
| Admin | admin@uni.edu | Admin@123 |
| Teacher | meera@uni.edu | Teacher@123 |
| Student | student1@uni.edu | Student@123 |

API docs: http://localhost:5000/api/docs  - Postman: import http://localhost:5000/api/docs.json

## Who can do what
| Feature | Admin | Teacher | Student |
|---|---|---|---|
| Users, departments, courses, subjects (CRUD) | yes | read only | read only |
| Take attendance / upload marks | any subject | own subjects | no |
| View attendance / marks | via teacher view | own subjects | own only |
| Post notices | yes | yes | no |
| Profile photo, change password | yes | yes | yes |

## Structure
```
backend/  config/ models/ controllers/ routes/ middleware/ scripts/ uploads/ app.js server.js seed.js
frontend/ index.html styles.css app.js     (served by Express)
docs/     DESIGN.md (architecture, ERD, use cases, sequence)  CO_MAPPING.md  loadtest.js (k6)
```

## Notes
- Public signup creates students only. Admins create teachers and other admins from the Users page.
- A student sees attendance and marks only after an admin sets their course and semester, and a subject exists for it.
- Uploaded files are served from `/uploads` with random names. For stricter privacy, move notice files behind an authenticated route.
- Deploy: backend on Render/Railway with `MONGO_URI` from MongoDB Atlas, `JWT_SECRET`, `NODE_ENV=production`, `CLIENT_ORIGIN` set to your site URL.
