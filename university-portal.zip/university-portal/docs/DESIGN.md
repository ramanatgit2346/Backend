# Design Documents

## Architecture (CO1)
```mermaid
flowchart LR
  B[Browser SPA<br/>HTML/CSS/JS] -->|HTTPS + Bearer JWT| E[Express app]
  E --> M1[helmet / cors / rate-limit / mongo-sanitize]
  M1 --> M2[protect: verify JWT]
  M2 --> M3[restrictTo: role check]
  M3 --> V[express-validator]
  V --> C[Controllers]
  C --> O[Mongoose models]
  O --> D[(MongoDB)]
  C --> F[(uploads/ via multer)]
```
Request lifecycle: `server.js` connects MongoDB, then `app.js` applies security middleware, `routes/index.js` chains
authentication -> authorization -> validation -> controller, and `middleware/error.js` turns every failure into a JSON error.

## ERD (CO3)
```mermaid
erDiagram
  DEPARTMENT ||--o{ COURSE : has
  COURSE ||--o{ SUBJECT : contains
  COURSE ||--o{ USER : enrols
  DEPARTMENT ||--o{ USER : employs
  USER ||--o{ SUBJECT : teaches
  SUBJECT ||--o{ ATTENDANCE : records
  SUBJECT ||--o{ MARKS : records
  USER ||--o{ ATTENDANCE : student
  USER ||--o{ MARKS : student
  USER ||--o{ NOTICE : posts
  USER { string name string email string password string role number semester string rollNo string photo bool active }
  SUBJECT { string name string code number semester number credits }
  ATTENDANCE { date date string status }
  MARKS { string exam number score number maxScore }
  NOTICE { string title string body string audience string file }
```
Unique indexes: `Attendance(subject, student, date)`, `Marks(subject, student, exam)`, `User.email`, `User.rollNo` (sparse).

## Use cases (CO3)
| Actor | Use cases |
|---|---|
| Admin | Manage users, departments, courses, subjects; assign teachers; post/delete any notice; view dashboard counts |
| Teacher | See own subjects; take attendance; upload marks; post notices |
| Student | Register/sign in; view own attendance %, own marks, notices; update photo and password |

## Sequence: teacher marks attendance (CO3)
```mermaid
sequenceDiagram
  actor T as Teacher
  participant UI as Frontend
  participant API as Express
  participant DB as MongoDB
  T->>UI: choose subject + date
  UI->>API: GET /subjects/:id/students (Bearer JWT)
  API->>API: protect -> restrictTo(admin, teacher) -> ownSubject
  API->>DB: find students by course + semester
  DB-->>UI: roster
  T->>UI: set statuses, Save
  UI->>API: POST /attendance
  API->>API: validate body, confirm every student is in the roster
  API->>DB: bulkWrite upserts
  API-->>UI: 201 saved
```
