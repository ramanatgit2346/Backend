# CO Mapping and Evaluation

| CO | Where it is satisfied | Evidence to show |
|---|---|---|
| CO1 - Node.js / Express / MongoDB architecture | `docs/DESIGN.md` architecture + lifecycle; folders `config/ models/ controllers/ routes/ middleware/` | Diagram, folder tree, `server.js` -> `app.js` -> `routes` walk-through |
| CO2 - Working REST APIs, CRUD, upload, auth | `routes/index.js`, `controllers/*`, `middleware/upload.js`; Swagger at `/api/docs` | Postman run (import `/api/docs.json`), CRUD on 4 collections, photo + notice upload |
| CO3 - Analysis and design | `docs/DESIGN.md`: ERD, use cases, sequence diagram, role workflows | Diagrams in report; SRS built from the role table in README |
| CO4 - Security and performance evaluation | Security table below; indexes, pagination; `docs/loadtest.js` | Unauthorized-access demo (student calling `/api/users` -> 403), k6 output screenshot |
| CO5 - Full-stack integration | `frontend/` SPA served by Express, calling the API with JWT | Demo video: register -> login -> role dashboards -> attendance/marks flow |

## Security evaluation
| Threat | Control | Where |
|---|---|---|
| Password theft | bcrypt, cost 12; `select:false` on the hash | `models/User.js` |
| Forged / expired session | Signed JWT with expiry, user re-loaded each request, disabled accounts rejected | `middleware/auth.js` |
| Privilege escalation | `restrictTo(role)` per route; public signup forced to `student`; teachers limited to their own subjects (`ownSubject`); students only reach `/me` endpoints | `routes/index.js`, `controllers/helpers.js` |
| Mass assignment | Field whitelist (`pick`) on every write | `controllers/crud.js` |
| NoSQL injection | `express-mongo-sanitize`; typed validation; `String()` on filters | `app.js`, `crud.js` |
| Brute force | 20 login/register attempts per 15 min per IP; 600 API calls per 15 min | `routes/index.js`, `app.js` |
| XSS / clickjacking / sniffing | Helmet headers incl. CSP; frontend escapes all data; no inline scripts | `app.js`, `frontend/app.js` |
| Malicious uploads | Mimetype whitelist, random filenames, 2 MB / 5 MB limits | `middleware/upload.js` |
| Secret leakage | `.env` ignored by git; server refuses to start without `JWT_SECRET` | `server.js` |
| Error leakage | Central handler hides 500 details in production | `middleware/error.js` |

## Performance evaluation
- **Indexes:** roster lookup `(role, course, semester)`, attendance `(subject, student, date)` unique, `(student)`, marks likewise.
- **Pagination:** every list endpoint takes `page` and `limit` (max 100).
- **Bulk writes:** attendance and marks use one `bulkWrite` per save instead of one query per student.
- **Compression** enabled with gzip.
- **Load test:** `k6 run docs/loadtest.js` (50 virtual users, p95 < 500 ms, error rate < 1 %). Paste your own numbers in the report; they depend on your machine.
