// k6 load test:  k6 run docs/loadtest.js
// Measures login + a paginated list + a student read under 50 virtual users.
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [{ duration: '20s', target: 50 }, { duration: '40s', target: 50 }, { duration: '10s', target: 0 }],
  thresholds: { http_req_failed: ['rate<0.01'], http_req_duration: ['p(95)<500'] }
};
const BASE = __ENV.BASE_URL || 'http://localhost:5000/api';
const json = { headers: { 'Content-Type': 'application/json' } };

export function setup() {
  const login = (email, password) => http.post(`${BASE}/auth/login`, JSON.stringify({ email, password }), json).json('token');
  return { admin: login('admin@uni.edu', 'Admin@123'), student: login('student1@uni.edu', 'Student@123') };
}
export default function (d) {
  const a = { headers: { Authorization: `Bearer ${d.admin}` } };
  const s = { headers: { Authorization: `Bearer ${d.student}` } };
  check(http.get(`${BASE}/users?page=1&limit=20`, a), { 'users 200': (r) => r.status === 200 });
  check(http.get(`${BASE}/attendance/me`, s), { 'attendance 200': (r) => r.status === 200 });
  check(http.get(`${BASE}/marks/me`, s), { 'marks 200': (r) => r.status === 200 });
  check(http.get(`${BASE}/users`, s), { 'student blocked from admin route (403)': (r) => r.status === 403 });
  sleep(1);
}
