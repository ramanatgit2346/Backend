@echo off
setlocal
cd /d "%~dp0backend"
where node >nul 2>nul
if errorlevel 1 ( echo Node.js 18 or newer is required. Install it from https://nodejs.org and run this again. & pause & exit /b 1 )

echo [1/4] Installing dependencies...
call npm install --no-audit --no-fund
if errorlevel 1 ( echo npm install failed. & pause & exit /b 1 )

echo [2/4] Creating .env with a random JWT secret...
node scripts\make-env.js

echo [3/4] Loading demo data (MongoDB must be running on this machine, or set MONGO_URI in backend\.env to your Atlas URL)...
call npm run seed

echo [4/4] Starting the portal at http://localhost:5000  (API docs at /api/docs)
start "" http://localhost:5000
call npm start
