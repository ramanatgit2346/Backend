# Run: powershell -ExecutionPolicy Bypass -File .\setup.ps1
Set-Location (Join-Path $PSScriptRoot 'backend')
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Write-Host 'Node.js 18+ is required: https://nodejs.org'; exit 1 }
Write-Host '[1/4] Installing dependencies...'; npm install --no-audit --no-fund
Write-Host '[2/4] Creating .env...'; node scripts/make-env.js
Write-Host '[3/4] Seeding demo data (MongoDB must be running)...'; npm run seed
Write-Host '[4/4] Starting at http://localhost:5000'; Start-Process 'http://localhost:5000'; npm start
