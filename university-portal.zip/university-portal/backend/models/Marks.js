const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  exam: { type: String, enum: ['internal1', 'internal2', 'assignment', 'midterm', 'final'], required: true },
  score: { type: Number, required: true, min: 0 },
  maxScore: { type: Number, required: true, min: 1 },
  uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });
schema.index({ subject: 1, student: 1, exam: 1 }, { unique: true });
schema.index({ student: 1 });
schema.pre('validate', function (next) {
  if (this.score > this.maxScore) this.invalidate('score', 'Score cannot exceed the maximum score');
  next();
});
module.exports = mongoose.model('Marks', schema);
