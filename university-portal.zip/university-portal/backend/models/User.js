const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: { type: String, required: [true, 'Name is required'], trim: true, maxlength: 80 },
  email: {
    type: String, required: [true, 'Email is required'], unique: true, lowercase: true, trim: true,
    match: [/^\S+@\S+\.\S+$/, 'Enter a valid email address']
  },
  password: { type: String, required: [true, 'Password is required'], minlength: [8, 'Password must be at least 8 characters'], select: false },
  role: { type: String, enum: ['admin', 'teacher', 'student'], default: 'student' },
  department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
  course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course' },
  semester: { type: Number, min: 1, max: 12 },
  rollNo: { type: String, trim: true, unique: true, sparse: true },
  photo: String,
  active: { type: Boolean, default: true }
}, { timestamps: true });

userSchema.index({ role: 1, course: 1, semester: 1 }); // roster lookups

userSchema.pre('save', async function (next) {
  if (this.isModified('password')) this.password = await bcrypt.hash(this.password, 12);
  next();
});
userSchema.methods.matchPassword = function (plain) { return bcrypt.compare(plain, this.password); };
userSchema.set('toJSON', { transform: (_d, ret) => { delete ret.password; delete ret.__v; return ret; } });

module.exports = mongoose.model('User', userSchema);
