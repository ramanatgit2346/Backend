const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  name: { type: String, required: [true, 'Course name is required'], trim: true },
  code: { type: String, required: [true, 'Course code is required'], unique: true, uppercase: true, trim: true },
  department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', required: [true, 'Department is required'], index: true },
  semesters: { type: Number, default: 4, min: 1, max: 12 }
}, { timestamps: true });
module.exports = mongoose.model('Course', schema);
