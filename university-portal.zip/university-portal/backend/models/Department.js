const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  name: { type: String, required: [true, 'Department name is required'], unique: true, trim: true },
  code: { type: String, required: [true, 'Department code is required'], unique: true, uppercase: true, trim: true }
}, { timestamps: true });
module.exports = mongoose.model('Department', schema);
