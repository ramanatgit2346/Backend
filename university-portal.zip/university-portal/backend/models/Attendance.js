const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  date: { type: Date, required: true },
  status: { type: String, enum: ['present', 'absent', 'late'], required: true },
  markedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });
schema.index({ subject: 1, student: 1, date: 1 }, { unique: true }); // one record per student per class day
schema.index({ student: 1 });
module.exports = mongoose.model('Attendance', schema);
