const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  name: { type: String, required: [true, 'Subject name is required'], trim: true },
  code: { type: String, required: [true, 'Subject code is required'], unique: true, uppercase: true, trim: true },
  course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: [true, 'Course is required'] },
  semester: { type: Number, required: [true, 'Semester is required'], min: 1, max: 12 },
  credits: { type: Number, default: 3, min: 1, max: 10 },
  teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true }
}, { timestamps: true });
schema.index({ course: 1, semester: 1 });
module.exports = mongoose.model('Subject', schema);
