const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 140 },
  body: { type: String, required: [true, 'Message is required'], trim: true, maxlength: 4000 },
  audience: { type: String, enum: ['all', 'students', 'teachers'], default: 'all' },
  file: String,
  postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
}, { timestamps: true });
schema.index({ createdAt: -1 });
module.exports = mongoose.model('Notice', schema);
