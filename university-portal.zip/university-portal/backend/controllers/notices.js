const Notice = require('../models/Notice');
const { ApiError, asyncHandler, pick } = require('../utils');

exports.list = asyncHandler(async (req, res) => {
  const role = req.user.role;
  const query = role === 'admin' ? {} : { audience: { $in: ['all', role === 'student' ? 'students' : 'teachers'] } };
  const data = await Notice.find(query).populate('postedBy', 'name role').sort('-createdAt').limit(50);
  res.json({ success: true, data });
});

exports.create = asyncHandler(async (req, res) => {
  const body = pick(req.body, ['title', 'body', 'audience']);
  if (req.file) body.file = `/uploads/notices/${req.file.filename}`;
  const notice = await Notice.create({ ...body, postedBy: req.user._id });
  res.status(201).json({ success: true, data: notice });
});

exports.remove = asyncHandler(async (req, res) => {
  const notice = await Notice.findById(req.params.id);
  if (!notice) throw new ApiError(404, 'Notice not found');
  if (req.user.role !== 'admin' && String(notice.postedBy) !== String(req.user._id)) throw new ApiError(403, 'You can only delete your own notices');
  await notice.deleteOne();
  res.json({ success: true, message: 'Notice deleted' });
});
