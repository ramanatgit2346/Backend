const Attendance = require('../models/Attendance');
const { ApiError, asyncHandler } = require('../utils');
const { ownSubject, roster } = require('./helpers');

const dayOf = (value) => { const d = new Date(value); d.setUTCHours(0, 0, 0, 0); return d; };

// Teacher/admin: mark attendance for a subject on one date (idempotent - re-saving updates)
exports.mark = asyncHandler(async (req, res) => {
  const { subject: subjectId, date, records } = req.body;
  const subject = await ownSubject(req.user, subjectId);
  const allowed = new Set((await roster(subject)).map((s) => String(s._id)));
  const bad = records.find((r) => !allowed.has(String(r.student)));
  if (bad) throw new ApiError(400, 'One or more students are not enrolled in this subject');
  const day = dayOf(date);
  await Attendance.bulkWrite(records.map((r) => ({
    updateOne: {
      filter: { subject: subject._id, student: r.student, date: day },
      update: { $set: { status: r.status, markedBy: req.user._id } },
      upsert: true
    }
  })));
  res.status(201).json({ success: true, message: `Attendance saved for ${records.length} students` });
});

// Teacher/admin: see what was recorded for a subject on a date
exports.forDate = asyncHandler(async (req, res) => {
  const subject = await ownSubject(req.user, req.query.subject);
  const data = await Attendance.find({ subject: subject._id, date: dayOf(req.query.date) }).select('student status');
  res.json({ success: true, data });
});

// Student: own attendance with per-subject percentage
exports.mine = asyncHandler(async (req, res) => {
  const records = await Attendance.find({ student: req.user._id }).populate('subject', 'name code').sort('-date').lean();
  const bySubject = {};
  for (const r of records) {
    const key = String(r.subject._id);
    const s = (bySubject[key] ||= { subject: r.subject, total: 0, attended: 0, absent: 0 });
    s.total += 1;
    if (r.status === 'absent') s.absent += 1; else s.attended += 1;
  }
  const summary = Object.values(bySubject).map((s) => ({ ...s, percentage: Math.round((s.attended / s.total) * 100) }));
  res.json({ success: true, summary, recent: records.slice(0, 20) });
});
