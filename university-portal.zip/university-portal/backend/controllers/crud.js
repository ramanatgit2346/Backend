const { ApiError, asyncHandler, escapeRegex, pick } = require('../utils');

// Generic CRUD factory with pagination, search, filters and field whitelisting
module.exports = (Model, { fields, populate = [], search = [], filters = [], label = 'Record' }) => ({
  list: asyncHandler(async (req, res) => {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
    const query = {};
    filters.forEach((f) => { if (req.query[f]) query[f] = String(req.query[f]); });
    if (req.query.q && search.length) {
      const rx = new RegExp(escapeRegex(req.query.q), 'i');
      query.$or = search.map((f) => ({ [f]: rx }));
    }
    const sort = req.query.sort ? String(req.query.sort).replace(/[^\w\- ]/g, '') : '-createdAt';
    const [data, total] = await Promise.all([
      Model.find(query).populate(populate).sort(sort).skip((page - 1) * limit).limit(limit),
      Model.countDocuments(query)
    ]);
    res.json({ success: true, page, limit, total, pages: Math.ceil(total / limit), data });
  }),

  get: asyncHandler(async (req, res) => {
    const doc = await Model.findById(req.params.id).populate(populate);
    if (!doc) throw new ApiError(404, `${label} not found`);
    res.json({ success: true, data: doc });
  }),

  create: asyncHandler(async (req, res) => {
    const doc = await Model.create(pick(req.body, fields));
    res.status(201).json({ success: true, data: doc });
  }),

  update: asyncHandler(async (req, res) => {
    const doc = await Model.findById(req.params.id);
    if (!doc) throw new ApiError(404, `${label} not found`);
    doc.set(pick(req.body, fields));
    await doc.save(); // runs validators and the password-hash hook
    res.json({ success: true, data: doc });
  }),

  remove: asyncHandler(async (req, res) => {
    const doc = await Model.findByIdAndDelete(req.params.id);
    if (!doc) throw new ApiError(404, `${label} not found`);
    res.json({ success: true, message: `${label} deleted` });
  })
});
