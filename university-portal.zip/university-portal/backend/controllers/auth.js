const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Course = require('../models/Course');
const { ApiError, asyncHandler, pick } = require('../utils');

const sign = (user) => jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '1d' });

// Public self-registration always creates a student; teachers/admins are created by an admin
exports.register = asyncHandler(async (req, res) => {
  const user = await User.create({ ...pick(req.body, ['name', 'email', 'password', 'rollNo', 'course', 'semester']), role: 'student' });
  res.status(201).json({ success: true, token: sign(user), user });
});

exports.login = asyncHandler(async (req, res) => {
  const user = await User.findOne({ email: req.body.email.toLowerCase() }).select('+password');
  if (!user || !(await user.matchPassword(req.body.password))) throw new ApiError(401, 'Invalid email or password');
  if (!user.active) throw new ApiError(403, 'This account is disabled. Contact the administrator');
  res.json({ success: true, token: sign(user), user });
});

exports.me = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).populate('department course', 'name code');
  res.json({ success: true, user });
});

exports.changePassword = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('+password');
  if (!(await user.matchPassword(req.body.currentPassword))) throw new ApiError(400, 'Current password is incorrect');
  user.password = req.body.newPassword;
  await user.save();
  res.json({ success: true, message: 'Password updated' });
});

exports.uploadPhoto = asyncHandler(async (req, res) => {
  if (!req.file) throw new ApiError(400, 'Choose an image to upload');
  req.user.photo = `/uploads/photos/${req.file.filename}`;
  await req.user.save();
  res.json({ success: true, user: req.user });
});

// Course choices for the registration form
exports.options = asyncHandler(async (_req, res) => {
  res.json({ success: true, courses: await Course.find().select('name code semesters').sort('name') });
});
