const Subject = require('../models/Subject');
const { asyncHandler } = require('../utils');
const { ownSubject, roster } = require('./helpers');

exports.mine = asyncHandler(async (req, res) => {
  const data = await Subject.find({ teacher: req.user._id }).populate('course', 'name code').sort('name');
  res.json({ success: true, data });
});

exports.students = asyncHandler(async (req, res) => {
  const subject = await ownSubject(req.user, req.params.id);
  res.json({ success: true, data: await roster(subject) });
});
