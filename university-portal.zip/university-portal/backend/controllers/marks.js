const Marks = require('../models/Marks');
const { ApiError, asyncHandler } = require('../utils');
const { ownSubject, roster } = require('./helpers');

// Teacher/admin: upload marks for one exam of one subject (re-saving updates)
exports.upload = asyncHandler(async (req, res) => {
  const { subject: subjectId, exam, maxScore, records } = req.body;
  const subject = await ownSubject(req.user, subjectId);
  const allowed = new Set((await roster(subject)).map((s) => String(s._id)));
  if (records.some((r) => !allowed.has(String(r.student)))) throw new ApiError(400, 'One or more students are not enrolled in this subject');
  if (records.some((r) => Number(r.score) > Number(maxScore))) throw new ApiError(400, 'A score is higher than the maximum score');
  await Marks.bulkWrite(records.map((r) => ({
    updateOne: {
      filter: { subject: subject._id, student: r.student, exam },
      update: { $set: { score: r.score, maxScore, uploadedBy: req.user._id } },
      upsert: true
    }
  })));
  res.status(201).json({ success: true, message: `Marks saved for ${records.length} students` });
});

exports.forExam = asyncHandler(async (req, res) => {
  const subject = await ownSubject(req.user, req.query.subject);
  const data = await Marks.find({ subject: subject._id, exam: req.query.exam }).select('student score maxScore');
  res.json({ success: true, data });
});

// Student: only the signed-in student's own marks
exports.mine = asyncHandler(async (req, res) => {
  const data = await Marks.find({ student: req.user._id }).populate('subject', 'name code').sort('subject exam').lean();
  res.json({ success: true, data });
});
