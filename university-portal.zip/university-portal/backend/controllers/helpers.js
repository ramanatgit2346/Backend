const Subject = require('../models/Subject');
const User = require('../models/User');
const { ApiError } = require('../utils');

// Returns the subject if the user may manage it (admin, or the teacher assigned to it)
exports.ownSubject = async (user, subjectId) => {
  const subject = await Subject.findById(subjectId);
  if (!subject) throw new ApiError(404, 'Subject not found');
  if (user.role === 'teacher' && String(subject.teacher) !== String(user._id)) {
    throw new ApiError(403, 'You are not assigned to this subject');
  }
  return subject;
};

// Students who belong to a subject: same course and semester
exports.roster = (subject) =>
  User.find({ role: 'student', active: true, course: subject.course, semester: subject.semester })
    .select('name email rollNo photo').sort('rollNo name');
