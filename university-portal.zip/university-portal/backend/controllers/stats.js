const User = require('../models/User');
const Department = require('../models/Department');
const Course = require('../models/Course');
const Subject = require('../models/Subject');
const Notice = require('../models/Notice');
const Attendance = require('../models/Attendance');
const { asyncHandler } = require('../utils');

exports.overview = asyncHandler(async (_req, res) => {
  const [students, teachers, departments, courses, subjects, notices, attendanceRecords] = await Promise.all([
    User.countDocuments({ role: 'student' }), User.countDocuments({ role: 'teacher' }),
    Department.countDocuments(), Course.countDocuments(), Subject.countDocuments(),
    Notice.countDocuments(), Attendance.estimatedDocumentCount()
  ]);
  res.json({ success: true, data: { students, teachers, departments, courses, subjects, notices, attendanceRecords } });
});
