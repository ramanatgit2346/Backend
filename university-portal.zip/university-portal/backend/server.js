require('dotenv').config();
const connectDB = require('./config/db');

for (const key of ['MONGO_URI', 'JWT_SECRET']) {
  if (!process.env[key]) { console.error(`Missing ${key}. Run: node scripts/make-env.js`); process.exit(1); }
}
const app = require('./app');
const PORT = process.env.PORT || 5000;

connectDB()
  .then(() => app.listen(PORT, () => console.log(`University Portal running at http://localhost:${PORT}  (API docs: /api/docs)`)))
  .catch((err) => { console.error('Could not connect to MongoDB:', err.message); process.exit(1); });
