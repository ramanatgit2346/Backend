const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const compression = require('compression');
const mongoSanitize = require('express-mongo-sanitize');
const rateLimit = require('express-rate-limit');
const swaggerUi = require('swagger-ui-express');
const routes = require('./routes');
const spec = require('./config/swagger');
const { notFound, errorHandler } = require('./middleware/error');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

app.use(helmet({ crossOriginResourcePolicy: { policy: 'same-site' } }));
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5000' }));
app.use(compression());
if (process.env.NODE_ENV !== 'test') app.use(morgan('dev'));
app.use(express.json({ limit: '100kb' }));
app.use(mongoSanitize()); // blocks NoSQL operator injection ($ and . in keys)
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: process.env.NODE_ENV === 'test' ? 100000 : 600, standardHeaders: true, legacyHeaders: false, message: { success: false, message: 'Too many requests. Slow down' } }));

app.get('/api/health', (_req, res) => res.json({ success: true, status: 'ok', uptime: process.uptime() }));
app.get('/api/docs.json', (_req, res) => res.json(spec)); // import this URL into Postman
app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(spec, { customSiteTitle: 'University Portal API' }));
app.use('/api', routes);
app.use('/api', notFound);

app.use('/uploads', express.static(path.join(__dirname, 'uploads'), { index: false, dotfiles: 'deny' }));
app.use(express.static(path.join(__dirname, '..', 'frontend')));
app.use(errorHandler);

module.exports = app;
