// Creates backend/.env with a random JWT secret if one does not exist yet.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const target = path.join(__dirname, '..', '.env');
if (fs.existsSync(target)) { console.log('.env already exists - leaving it unchanged'); process.exit(0); }
const example = fs.readFileSync(path.join(__dirname, '..', '.env.example'), 'utf8');
fs.writeFileSync(target, example.replace('replace_with_a_long_random_string', crypto.randomBytes(48).toString('hex')));
console.log('Created backend/.env with a random JWT secret');
