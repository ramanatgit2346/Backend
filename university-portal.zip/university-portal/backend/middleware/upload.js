const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const { ApiError } = require('../utils');

const TYPES = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'application/pdf': '.pdf' };

// kind: 'photos' (images, 2 MB) or 'notices' (images + PDF, 5 MB)
module.exports = (kind) => multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, '..', 'uploads', kind),
    filename: (_req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + TYPES[file.mimetype])
  }),
  limits: { fileSize: kind === 'photos' ? 2 * 1024 * 1024 : 5 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ok = TYPES[file.mimetype] && (kind === 'notices' || file.mimetype.startsWith('image/'));
    cb(ok ? null : new ApiError(400, kind === 'photos' ? 'Upload a JPG, PNG or WebP image' : 'Upload a JPG, PNG, WebP or PDF file'), !!ok);
  }
});
