const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { ApiError, asyncHandler } = require('../utils');

// Authentication: verifies the Bearer token and loads the user
exports.protect = asyncHandler(async (req, _res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) throw new ApiError(401, 'Sign in to continue');
  let payload;
  try { payload = jwt.verify(token, process.env.JWT_SECRET); }
  catch { throw new ApiError(401, 'Your session has expired. Sign in again'); }
  const user = await User.findById(payload.id);
  if (!user || !user.active) throw new ApiError(401, 'This account does not exist or is disabled');
  req.user = user;
  next();
});

// Authorization: role-based access control
exports.restrictTo = (...roles) => (req, _res, next) =>
  roles.includes(req.user.role) ? next() : next(new ApiError(403, 'You do not have permission to do this'));
