const multer = require('multer');

exports.notFound = (req, res) =>
  res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.originalUrl}` });

// eslint-disable-next-line no-unused-vars
exports.errorHandler = (err, _req, res, _next) => {
  let status = err.status || 500;
  let message = err.message || 'Something went wrong';

  if (err.name === 'ValidationError') { status = 400; message = Object.values(err.errors).map((e) => e.message).join('. '); }
  else if (err.name === 'CastError') { status = 400; message = `Invalid value for ${err.path}`; }
  else if (err.code === 11000) { status = 409; message = `${Object.keys(err.keyValue || {})[0] || 'Value'} already exists`; }
  else if (err instanceof multer.MulterError) { status = 400; message = err.code === 'LIMIT_FILE_SIZE' ? 'File is too large' : err.message; }

  if (status >= 500) { console.error(err); message = process.env.NODE_ENV === 'production' ? 'Internal server error' : message; }
  res.status(status).json({ success: false, message });
};
