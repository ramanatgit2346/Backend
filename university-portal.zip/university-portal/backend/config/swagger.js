// OpenAPI 3 spec built from a compact table. Served at /api/docs (Swagger UI) and /api/docs.json (Postman import)
const R = { admin: 'Admin', teacher: 'Teacher', student: 'Student', any: 'Any signed-in user', public: 'Public' };
const rows = [
  ['post', '/auth/register', 'Auth', 'Register a student account', R.public],
  ['post', '/auth/login', 'Auth', 'Sign in and receive a JWT', R.public],
  ['get', '/auth/me', 'Auth', 'Current user profile', R.any],
  ['put', '/auth/password', 'Auth', 'Change own password', R.any],
  ['post', '/auth/photo', 'Auth', 'Upload profile photo (multipart, field "photo")', R.any],
  ['get', '/stats', 'Dashboard', 'Counts for the admin dashboard', R.admin],
  ['get', '/users', 'Users', 'List users (page, limit, q, role, course, semester)', R.admin],
  ['post', '/users', 'Users', 'Create a user with any role', R.admin],
  ['put', '/users/{id}', 'Users', 'Update a user', R.admin],
  ['delete', '/users/{id}', 'Users', 'Delete a user', R.admin],
  ['get', '/departments', 'Departments', 'List departments', R.any],
  ['post', '/departments', 'Departments', 'Create a department', R.admin],
  ['put', '/departments/{id}', 'Departments', 'Update a department', R.admin],
  ['delete', '/departments/{id}', 'Departments', 'Delete a department', R.admin],
  ['get', '/courses', 'Courses', 'List courses', R.any],
  ['post', '/courses', 'Courses', 'Create a course', R.admin],
  ['put', '/courses/{id}', 'Courses', 'Update a course', R.admin],
  ['delete', '/courses/{id}', 'Courses', 'Delete a course', R.admin],
  ['get', '/subjects', 'Subjects', 'List subjects', R.any],
  ['get', '/subjects/mine', 'Subjects', 'Subjects assigned to the signed-in teacher', R.teacher],
  ['get', '/subjects/{id}/students', 'Subjects', 'Students enrolled in a subject', 'Admin, Teacher (own subject)'],
  ['post', '/subjects', 'Subjects', 'Create a subject and assign a teacher', R.admin],
  ['put', '/subjects/{id}', 'Subjects', 'Update a subject', R.admin],
  ['delete', '/subjects/{id}', 'Subjects', 'Delete a subject', R.admin],
  ['post', '/attendance', 'Attendance', 'Mark attendance for a subject and date', 'Admin, Teacher (own subject)'],
  ['get', '/attendance', 'Attendance', 'Read attendance for a subject and date (?subject&date)', 'Admin, Teacher (own subject)'],
  ['get', '/attendance/me', 'Attendance', 'Own attendance summary', R.student],
  ['post', '/marks', 'Marks', 'Upload marks for a subject and exam', 'Admin, Teacher (own subject)'],
  ['get', '/marks', 'Marks', 'Read marks for a subject and exam (?subject&exam)', 'Admin, Teacher (own subject)'],
  ['get', '/marks/me', 'Marks', 'Own marks', R.student],
  ['get', '/notices', 'Notices', 'Notices for the signed-in role', R.any],
  ['post', '/notices', 'Notices', 'Post a notice with optional file (multipart)', 'Admin, Teacher'],
  ['delete', '/notices/{id}', 'Notices', 'Delete a notice', 'Admin, or the teacher who posted it']
];

const paths = {};
for (const [method, path, tag, summary, access] of rows) {
  const open = access === R.public;
  (paths[path] ||= {})[method] = {
    tags: [tag], summary, description: `Access: ${access}`,
    ...(open ? {} : { security: [{ bearerAuth: [] }] }),
    ...(path.includes('{id}') ? { parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }] } : {}),
    ...(['post', 'put'].includes(method) ? { requestBody: { content: { 'application/json': { schema: { type: 'object' } } } } } : {}),
    responses: { 200: { description: 'OK' }, 400: { description: 'Validation error' }, 401: { description: 'Not authenticated' }, 403: { description: 'Not permitted for this role' } }
  };
}

module.exports = {
  openapi: '3.0.3',
  info: { title: 'Secure University Management Portal API', version: '1.0.0', description: 'JWT-secured REST API with Admin / Teacher / Student roles. Use POST /auth/login, then Authorize with the token.' },
  servers: [{ url: '/api' }],
  components: { securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } } },
  paths
};
