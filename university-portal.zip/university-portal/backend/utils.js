class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
// keep only allowed keys and drop empty strings so optional fields stay unset
const pick = (obj, keys) => keys.reduce((o, k) => {
  if (obj[k] !== undefined && obj[k] !== '') o[k] = obj[k];
  return o;
}, {});
module.exports = { ApiError, asyncHandler, escapeRegex, pick };
