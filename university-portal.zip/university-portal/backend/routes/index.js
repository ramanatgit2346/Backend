const router = require('express').Router();
const { body, query } = require('express-validator');
const rateLimit = require('express-rate-limit');
const { protect, restrictTo } = require('../middleware/auth');
const validate = require('../middleware/validate');
const upload = require('../middleware/upload');
const { ApiError } = require('../utils');

const crud = require('../controllers/crud');
const auth = require('../controllers/auth');
const subjectsCtl = require('../controllers/subjects');
const attendance = require('../controllers/attendance');
const marks = require('../controllers/marks');
const notices = require('../controllers/notices');
const stats = require('../controllers/stats');

const User = require('../models/User');
const Department = require('../models/Department');
const Course = require('../models/Course');
const Subject = require('../models/Subject');

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: process.env.NODE_ENV === 'test' ? 10000 : 20, standardHeaders: true, legacyHeaders: false, message: { success: false, message: 'Too many attempts. Try again in 15 minutes' } });
const admin = restrictTo('admin');
const staff = restrictTo('admin', 'teacher');
const mongoId = (name, where = body) => where(name).isMongoId().withMessage(`${name} is invalid`);

// ---------- Auth ----------
router.get('/auth/options', auth.options);
router.post('/auth/register', authLimiter, [
  body('name').trim().notEmpty().withMessage('Name is required'),
  body('email').isEmail().withMessage('Enter a valid email address'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
], validate, auth.register);
router.post('/auth/login', authLimiter, [
  body('email').isEmail().withMessage('Enter a valid email address'),
  body('password').notEmpty().withMessage('Password is required')
], validate, auth.login);
router.get('/auth/me', protect, auth.me);
router.put('/auth/password', protect, [
  body('currentPassword').notEmpty().withMessage('Current password is required'),
  body('newPassword').isLength({ min: 8 }).withMessage('New password must be at least 8 characters')
], validate, auth.changePassword);
router.post('/auth/photo', protect, upload('photos').single('photo'), auth.uploadPhoto);

// ---------- Everything below requires a signed-in user ----------
router.use(protect);

router.get('/stats', admin, stats.overview);

// Users (admin only)
const users = crud(User, {
  fields: ['name', 'email', 'password', 'role', 'department', 'course', 'semester', 'rollNo', 'active'],
  populate: [{ path: 'department', select: 'name code' }, { path: 'course', select: 'name code' }],
  search: ['name', 'email', 'rollNo'], filters: ['role', 'course', 'semester'], label: 'User'
});
const notSelf = (req, _res, next) => (req.params.id === String(req.user._id) ? next(new ApiError(400, 'You cannot delete your own account')) : next());
router.route('/users').get(admin, users.list).post(admin, users.create);
router.route('/users/:id').get(admin, users.get).put(admin, users.update).delete(admin, notSelf, users.remove);

// Departments / courses / subjects: read for all, write for admin
const resource = (path, ctl) => {
  router.route(path).get(ctl.list).post(admin, ctl.create);
  router.route(`${path}/:id`).get(ctl.get).put(admin, ctl.update).delete(admin, ctl.remove);
};
resource('/departments', crud(Department, { fields: ['name', 'code'], search: ['name', 'code'], label: 'Department' }));
resource('/courses', crud(Course, { fields: ['name', 'code', 'department', 'semesters'], populate: [{ path: 'department', select: 'name code' }], search: ['name', 'code'], filters: ['department'], label: 'Course' }));

const subjects = crud(Subject, {
  fields: ['name', 'code', 'course', 'semester', 'credits', 'teacher'],
  populate: [{ path: 'course', select: 'name code' }, { path: 'teacher', select: 'name email' }],
  search: ['name', 'code'], filters: ['course', 'semester', 'teacher'], label: 'Subject'
});
router.get('/subjects/mine', restrictTo('teacher'), subjectsCtl.mine); // before /:id
router.get('/subjects/:id/students', staff, subjectsCtl.students);
resource('/subjects', subjects);

// Attendance
router.post('/attendance', staff, [
  mongoId('subject'), body('date').isISO8601().withMessage('Date is invalid'),
  body('records').isArray({ min: 1 }).withMessage('Add at least one student'),
  body('records.*.student').isMongoId().withMessage('Student id is invalid'),
  body('records.*.status').isIn(['present', 'absent', 'late']).withMessage('Status must be present, absent or late')
], validate, attendance.mark);
router.get('/attendance', staff, [mongoId('subject', query), query('date').isISO8601().withMessage('Date is invalid')], validate, attendance.forDate);
router.get('/attendance/me', restrictTo('student'), attendance.mine);

// Marks
const exams = ['internal1', 'internal2', 'assignment', 'midterm', 'final'];
router.post('/marks', staff, [
  mongoId('subject'), body('exam').isIn(exams).withMessage('Choose a valid exam'),
  body('maxScore').isFloat({ min: 1 }).withMessage('Maximum score must be at least 1'),
  body('records').isArray({ min: 1 }).withMessage('Add at least one student'),
  body('records.*.student').isMongoId().withMessage('Student id is invalid'),
  body('records.*.score').isFloat({ min: 0 }).withMessage('Scores must be 0 or more')
], validate, marks.upload);
router.get('/marks', staff, [mongoId('subject', query), query('exam').isIn(exams).withMessage('Choose a valid exam')], validate, marks.forExam);
router.get('/marks/me', restrictTo('student'), marks.mine);

// Notices
router.get('/notices', notices.list);
router.post('/notices', staff, upload('notices').single('file'), [
  body('title').trim().notEmpty().withMessage('Title is required'),
  body('body').trim().notEmpty().withMessage('Message is required')
], validate, notices.create);
router.delete('/notices/:id', staff, notices.remove);

module.exports = router;
