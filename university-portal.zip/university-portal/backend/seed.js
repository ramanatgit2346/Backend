// Demo data: node seed.js   (wipes the portal collections first)
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Department = require('./models/Department');
const Course = require('./models/Course');
const Subject = require('./models/Subject');
const Attendance = require('./models/Attendance');
const Marks = require('./models/Marks');
const Notice = require('./models/Notice');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Promise.all([User, Department, Course, Subject, Attendance, Marks, Notice].map((m) => m.deleteMany({})));

  const dept = await Department.create({ name: 'Computer Applications', code: 'CA' });
  const course = await Course.create({ name: 'Master of Computer Applications', code: 'MCA', department: dept._id, semesters: 4 });

  const admin = await User.create({ name: 'Portal Admin', email: 'admin@uni.edu', password: 'Admin@123', role: 'admin' });
  const [t1, t2] = await Promise.all([
    User.create({ name: 'Dr. Meera Kapoor', email: 'meera@uni.edu', password: 'Teacher@123', role: 'teacher', department: dept._id }),
    User.create({ name: 'Prof. Arjun Sethi', email: 'arjun@uni.edu', password: 'Teacher@123', role: 'teacher', department: dept._id })
  ]);

  const subjects = await Subject.create([
    { name: 'Backend Technologies', code: 'MCA-BT', course: course._id, semester: 1, credits: 4, teacher: t1._id },
    { name: 'Data Analytics', code: 'MCA-DA', course: course._id, semester: 1, credits: 4, teacher: t2._id },
    { name: 'Machine Learning', code: 'MCA-ML', course: course._id, semester: 1, credits: 3, teacher: t1._id }
  ]);

  const names = ['Aarav Singh', 'Simran Kaur', 'Rohan Verma', 'Ishita Sharma', 'Kabir Malhotra', 'Naina Gill'];
  const students = [];
  for (let i = 0; i < names.length; i++) {
    students.push(await User.create({
      name: names[i], email: `student${i + 1}@uni.edu`, password: 'Student@123', role: 'student',
      department: dept._id, course: course._id, semester: 1, rollNo: `25MCA${String(i + 1).padStart(3, '0')}`
    }));
  }

  // 12 class days of attendance and a set of marks
  const attendance = []; const marks = [];
  for (let d = 1; d <= 12; d++) {
    const day = new Date(); day.setUTCHours(0, 0, 0, 0); day.setUTCDate(day.getUTCDate() - d);
    for (const sub of subjects) for (const st of students) {
      const r = Math.random();
      attendance.push({ subject: sub._id, student: st._id, date: day, status: r < 0.78 ? 'present' : r < 0.88 ? 'late' : 'absent', markedBy: sub.teacher });
    }
  }
  for (const sub of subjects) for (const st of students) {
    marks.push({ subject: sub._id, student: st._id, exam: 'internal1', score: 12 + Math.floor(Math.random() * 9), maxScore: 20, uploadedBy: sub.teacher });
    marks.push({ subject: sub._id, student: st._id, exam: 'assignment', score: 6 + Math.floor(Math.random() * 5), maxScore: 10, uploadedBy: sub.teacher });
  }
  await Attendance.insertMany(attendance);
  await Marks.insertMany(marks);
  await Notice.create({ title: 'Welcome to the new portal', body: 'Check your attendance and marks here. Report any mismatch to your subject teacher within 7 days.', audience: 'all', postedBy: admin._id });

  console.log('Seeded. Sign in with:\n  admin@uni.edu / Admin@123\n  meera@uni.edu / Teacher@123\n  student1@uni.edu / Student@123');
  await mongoose.disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
