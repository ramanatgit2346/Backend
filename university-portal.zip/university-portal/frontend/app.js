(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const EXAMS = { internal1: 'Internal 1', internal2: 'Internal 2', assignment: 'Assignment', midterm: 'Mid-term', final: 'Final' };
  const today = () => new Date().toISOString().slice(0, 10);
  const fmt = (d) => new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
  const refName = (v) => (v && typeof v === 'object' ? v.name || v.code : v || '');

  let token = sessionStorage.getItem('token');
  let me = null;
  let rows = {};

  // ---------- API + feedback ----------
  async function api(path, { method = 'GET', body, form } = {}) {
    const opt = { method, headers: {} };
    if (token) opt.headers.Authorization = `Bearer ${token}`;
    if (form) opt.body = form;
    else if (body) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    const res = await fetch(`/api${path}`, opt);
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (res.status === 401 && token && !path.startsWith('/auth/login')) signOut();
      throw new Error(json.message || 'Something went wrong. Try again');
    }
    return json;
  }
  let toastTimer;
  function toast(msg, bad) {
    const t = $('#toast');
    t.textContent = msg; t.className = `toast show${bad ? ' bad' : ''}`;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.className = 'toast'), 3200);
  }
  const attempt = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } };

  // ---------- Auth ----------
  function showAuth() { $('#shell').hidden = true; $('#auth').hidden = false; loadCourses(); }
  function signOut() { token = null; me = null; sessionStorage.removeItem('token'); showAuth(); }
  async function loadCourses() {
    try {
      const { courses } = await api('/auth/options');
      $('#reg-course').innerHTML = '<option value="">Select course</option>' + courses.map((c) => `<option value="${esc(c._id)}">${esc(c.name)}</option>`).join('');
    } catch { /* optional */ }
  }
  function setTab(login) {
    $('#tab-login').classList.toggle('on', login); $('#tab-register').classList.toggle('on', !login);
    $('#login-form').hidden = !login; $('#register-form').hidden = login; $('#auth-error').textContent = '';
  }
  $('#tab-login').addEventListener('click', () => setTab(true));
  $('#tab-register').addEventListener('click', () => setTab(false));
  async function submitAuth(e, path) {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.target).entries());
    try {
      const res = await api(path, { method: 'POST', body });
      token = res.token; sessionStorage.setItem('token', token); me = res.user; await startShell();
    } catch (err) { $('#auth-error').textContent = err.message; }
  }
  $('#login-form').addEventListener('submit', (e) => submitAuth(e, '/auth/login'));
  $('#register-form').addEventListener('submit', (e) => submitAuth(e, '/auth/register'));
  $('#logout').addEventListener('click', signOut);

  // ---------- Shell + navigation ----------
  const NAV = {
    admin: [['overview', 'Overview'], ['users', 'Users'], ['departments', 'Departments'], ['courses', 'Courses'], ['subjects', 'Subjects'], ['notices', 'Notices'], ['profile', 'Profile']],
    teacher: [['overview', 'My subjects'], ['attendance', 'Attendance'], ['marks', 'Marks'], ['notices', 'Notices'], ['profile', 'Profile']],
    student: [['overview', 'Attendance'], ['mymarks', 'My marks'], ['notices', 'Notices'], ['profile', 'Profile']]
  };
  async function startShell() {
    if (!me || !me.role) me = (await api('/auth/me')).user;
    $('#auth').hidden = true; $('#shell').hidden = false;
    $('#who-name').textContent = me.name; $('#who-role').textContent = me.role;
    $('#nav').innerHTML = NAV[me.role].map(([k, l]) => `<button type="button" data-v="${k}">${l}</button>`).join('');
    go(NAV[me.role][0][0]);
  }
  $('#nav').addEventListener('click', (e) => { const b = e.target.closest('button[data-v]'); if (b) go(b.dataset.v); });

  const VIEWS = {
    overview: () => ({ admin: adminOverview, teacher: teacherOverview, student: studentOverview }[me.role]()),
    users: () => entityView('users'), departments: () => entityView('departments'),
    courses: () => entityView('courses'), subjects: () => entityView('subjects'),
    attendance, marks, mymarks, notices, profile
  };
  async function go(view) {
    document.querySelectorAll('#nav button').forEach((b) => b.classList.toggle('on', b.dataset.v === view));
    $('#main').innerHTML = '<p class="muted">Loading…</p>';
    try { await VIEWS[view](); $('#main').focus({ preventScroll: true }); } catch (e) { $('#main').innerHTML = `<p class="error">${esc(e.message)}</p>`; }
  }
  const main = () => $('#main');

  // ---------- Overviews ----------
  async function adminOverview() {
    const { data } = await api('/stats');
    const items = [['students', 'Students'], ['teachers', 'Teachers'], ['departments', 'Departments'], ['courses', 'Courses'], ['subjects', 'Subjects'], ['attendanceRecords', 'Attendance records'], ['notices', 'Notices']];
    main().innerHTML = `<header class="bar"><h1>Overview</h1></header><div class="stats">${items.map(([k, l]) => `<div class="stat"><b>${data[k]}</b><span>${l}</span></div>`).join('')}</div>
      <div class="panel"><h2>Getting started</h2><p class="muted">Create departments and courses, then subjects with an assigned teacher. Students see only the subjects of their course and semester.</p></div>`;
  }

  async function teacherOverview() {
    const { data } = await api('/subjects/mine');
    main().innerHTML = `<header class="bar"><h1>My subjects</h1></header>` + (data.length
      ? `<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Course</th><th>Semester</th><th>Credits</th></tr></thead><tbody>${data.map((s) => `<tr><td>${esc(s.name)} <span class="pill">${esc(s.code)}</span></td><td>${esc(refName(s.course))}</td><td>${s.semester}</td><td>${s.credits}</td></tr>`).join('')}</tbody></table></div>`
      : '<div class="panel empty">No subjects are assigned to you yet. Ask the administrator to assign one.</div>');
  }

  async function studentOverview() {
    const { summary, recent } = await api('/attendance/me');
    const bars = summary.map((s) => {
      const low = s.percentage < 75;
      return `<div class="att-row"><div><b>${esc(s.subject.name)}</b></div><div class="pct${low ? ' low' : ''}">${s.percentage}%</div>
        <div class="track" role="img" aria-label="${esc(s.subject.name)} attendance ${s.percentage} percent"><i class="${low ? 'low' : ''}" style="width:${s.percentage}%"></i><u></u></div>
        <div class="meta">${s.attended} of ${s.total} classes attended${low ? ' — below the 75% requirement' : ''}</div></div>`;
    }).join('');
    main().innerHTML = `<header class="bar"><h1>My attendance</h1></header>` + (summary.length
      ? `<div class="panel att">${bars}</div><h2 style="margin:1.25rem 0 .6rem">Recent classes</h2>
        <div class="table-wrap"><table><thead><tr><th>Date</th><th>Subject</th><th>Status</th></tr></thead><tbody>${recent.map((r) => `<tr><td>${fmt(r.date)}</td><td>${esc(r.subject.name)}</td><td><span class="pill">${esc(r.status)}</span></td></tr>`).join('')}</tbody></table></div>`
      : '<div class="panel empty">No attendance has been recorded for you yet.</div>');
  }

  // ---------- Admin CRUD (config driven) ----------
  const E = {
    users: {
      title: 'Users', path: '/users', label: 'user',
      cols: [['name', 'Name'], ['email', 'Email'], ['role', 'Role', (v) => `<span class="pill">${esc(v)}</span>`], ['rollNo', 'Roll no'], ['course', 'Course', refName], ['semester', 'Sem']],
      fields: (editing) => [
        { k: 'name', l: 'Full name', req: 1 }, { k: 'email', l: 'Email', type: 'email', req: 1 },
        { k: 'password', l: editing ? 'New password (leave blank to keep)' : 'Password', type: 'password', req: !editing },
        { k: 'role', l: 'Role', type: 'select', req: 1, options: ['student', 'teacher', 'admin'].map((v) => ({ v, l: v })) },
        { k: 'department', l: 'Department', type: 'ref', ref: '/departments' },
        { k: 'course', l: 'Course', type: 'ref', ref: '/courses' },
        { k: 'semester', l: 'Semester', type: 'number' }, { k: 'rollNo', l: 'Roll number' },
        { k: 'active', l: 'Account', type: 'select', options: [{ v: 'true', l: 'Active' }, { v: 'false', l: 'Disabled' }] }
      ]
    },
    departments: {
      title: 'Departments', path: '/departments', label: 'department',
      cols: [['name', 'Name'], ['code', 'Code']],
      fields: () => [{ k: 'name', l: 'Name', req: 1 }, { k: 'code', l: 'Code', req: 1 }]
    },
    courses: {
      title: 'Courses', path: '/courses', label: 'course',
      cols: [['name', 'Name'], ['code', 'Code'], ['department', 'Department', refName], ['semesters', 'Semesters']],
      fields: () => [{ k: 'name', l: 'Name', req: 1 }, { k: 'code', l: 'Code', req: 1 }, { k: 'department', l: 'Department', type: 'ref', ref: '/departments', req: 1 }, { k: 'semesters', l: 'Number of semesters', type: 'number' }]
    },
    subjects: {
      title: 'Subjects', path: '/subjects', label: 'subject',
      cols: [['name', 'Name'], ['code', 'Code'], ['course', 'Course', refName], ['semester', 'Sem'], ['teacher', 'Teacher', refName]],
      fields: () => [{ k: 'name', l: 'Name', req: 1 }, { k: 'code', l: 'Code', req: 1 }, { k: 'course', l: 'Course', type: 'ref', ref: '/courses', req: 1 },
        { k: 'semester', l: 'Semester', type: 'number', req: 1 }, { k: 'credits', l: 'Credits', type: 'number' }, { k: 'teacher', l: 'Teacher', type: 'ref', ref: '/users?role=teacher', req: 0 }]
    }
  };

  async function entityView(key, q = '') {
    const e = E[key];
    const res = await api(`${e.path}?limit=100${q ? `&q=${encodeURIComponent(q)}` : ''}`);
    rows[key] = res.data;
    const head = e.cols.map((c) => `<th>${c[1]}</th>`).join('');
    const body = res.data.map((r) => `<tr>${e.cols.map(([k, , f]) => `<td>${f === refName ? esc(refName(r[k])) : f ? f(r[k]) : esc(r[k])}${k === 'name' && r.active === false ? ' <span class="pill">Disabled</span>' : ''}</td>`).join('')}
      <td class="actions"><button class="btn ghost sm" data-edit="${r._id}">Edit</button><button class="btn danger sm" data-del="${r._id}">Delete</button></td></tr>`).join('');
    main().innerHTML = `<header class="bar"><h1>${e.title}</h1><div class="tools">
      <input id="q" type="search" placeholder="Search ${e.title.toLowerCase()}" value="${esc(q)}" aria-label="Search"><button class="btn" id="add">Add ${e.label}</button></div></header>
      ${res.data.length ? `<div class="table-wrap"><table><thead><tr>${head}<th></th></tr></thead><tbody>${body}</tbody></table></div>` : `<div class="panel empty">No ${e.title.toLowerCase()} found. Add the first one.</div>`}
      <p class="muted small">${res.total} total</p>`;
    $('#q').addEventListener('keydown', (ev) => { if (ev.key === 'Enter') entityView(key, ev.target.value.trim()); });
    $('#add').addEventListener('click', () => openForm(key));
    main().querySelectorAll('[data-edit]').forEach((b) => b.addEventListener('click', () => openForm(key, rows[key].find((r) => r._id === b.dataset.edit))));
    main().querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', attempt(async () => {
      if (!confirm(`Delete this ${e.label}? This cannot be undone.`)) return;
      await api(`${e.path}/${b.dataset.del}`, { method: 'DELETE' }); toast(`${e.label[0].toUpperCase() + e.label.slice(1)} deleted`); entityView(key, q);
    })));
  }

  async function openForm(key, record) {
    const e = E[key]; const editing = !!record;
    const fields = e.fields(editing);
    const refs = {};
    await Promise.all(fields.filter((f) => f.type === 'ref').map(async (f) => {
      const sep = f.ref.includes('?') ? '&' : '?';
      refs[f.k] = (await api(`${f.ref}${sep}limit=100`)).data;
    }));
    const input = (f) => {
      const val = record ? (record[f.k] && typeof record[f.k] === 'object' ? record[f.k]._id : record[f.k]) : '';
      const req = f.req ? 'required' : '';
      if (f.type === 'select') return `<select name="${f.k}" ${req}>${f.options.map((o) => `<option value="${esc(o.v)}"${String(val ?? (f.k === 'active' ? 'true' : '')) === o.v ? ' selected' : ''}>${esc(o.l)}</option>`).join('')}</select>`;
      if (f.type === 'ref') return `<select name="${f.k}" ${req}><option value="">${f.req ? 'Select…' : 'None'}</option>${refs[f.k].map((o) => `<option value="${o._id}"${val === o._id ? ' selected' : ''}>${esc(o.name)}</option>`).join('')}</select>`;
      return `<input name="${f.k}" type="${f.type || 'text'}" value="${f.type === 'password' ? '' : esc(val)}" ${req} ${f.type === 'password' ? 'minlength="8" autocomplete="new-password"' : ''}>`;
    };
    const form = $('#modal-form');
    form.innerHTML = `<h2>${editing ? 'Edit' : 'Add'} ${e.label}</h2>${fields.map((f) => `<label>${f.l}${input(f)}</label>`).join('')}
      <p id="form-error" class="error" role="alert"></p>
      <div class="modal-actions"><button type="button" class="btn ghost" id="cancel">Cancel</button><button class="btn" type="submit">Save ${e.label}</button></div>`;
    $('#modal').showModal();
    $('#cancel').onclick = () => $('#modal').close();
    form.onsubmit = async (ev) => {
      ev.preventDefault();
      const body = {};
      fields.forEach((f) => {
        let v = new FormData(form).get(f.k);
        if (v === '' || v === null) return;
        if (f.type === 'number') v = Number(v);
        if (f.k === 'active') v = v === 'true';
        body[f.k] = v;
      });
      try {
        await api(editing ? `${e.path}/${record._id}` : e.path, { method: editing ? 'PUT' : 'POST', body });
        $('#modal').close(); toast(`${e.label[0].toUpperCase() + e.label.slice(1)} saved`); entityView(key);
      } catch (err) { $('#form-error').textContent = err.message; }
    };
  }

  // ---------- Teacher: attendance and marks ----------
  const subjectPicker = (subs) => `<label>Subject<select id="sub">${subs.map((s) => `<option value="${s._id}">${esc(s.name)} (sem ${s.semester})</option>`).join('')}</select></label>`;
  const noSubjects = '<div class="panel empty">No subjects are assigned to you yet.</div>';

  async function attendance() {
    const subs = (await api('/subjects/mine')).data;
    main().innerHTML = `<header class="bar"><h1>Attendance</h1></header>`;
    if (!subs.length) { main().innerHTML += noSubjects; return; }
    main().insertAdjacentHTML('beforeend', `<div class="panel row2">${subjectPicker(subs)}<label>Date<input id="date" type="date" value="${today()}" max="${today()}"></label></div><div id="sheet"></div>`);
    const load = attempt(async () => {
      const subject = $('#sub').value; const date = $('#date').value;
      if (!date) return;
      const [roster, existing] = await Promise.all([api(`/subjects/${subject}/students`), api(`/attendance?subject=${subject}&date=${date}`)]);
      const saved = Object.fromEntries(existing.data.map((x) => [x.student, x.status]));
      if (!roster.data.length) { $('#sheet').innerHTML = '<div class="panel empty">No students are enrolled in this subject’s course and semester.</div>'; return; }
      $('#sheet').innerHTML = `<div class="table-wrap"><table><thead><tr><th>Roll no</th><th>Student</th><th>Status</th></tr></thead><tbody>${roster.data.map((s) => `<tr><td>${esc(s.rollNo)}</td><td>${esc(s.name)}</td>
        <td><select data-student="${s._id}" aria-label="Status for ${esc(s.name)}">${['present', 'absent', 'late'].map((v) => `<option value="${v}"${(saved[s._id] || 'present') === v ? ' selected' : ''}>${v}</option>`).join('')}</select></td></tr>`).join('')}</tbody></table></div>
        <div class="bar" style="margin-top:1rem"><button class="btn ghost" id="all">Mark all present</button><button class="btn" id="save">Save attendance</button></div>`;
      $('#all').onclick = () => document.querySelectorAll('[data-student]').forEach((s) => (s.value = 'present'));
      $('#save').onclick = attempt(async () => {
        const records = [...document.querySelectorAll('[data-student]')].map((s) => ({ student: s.dataset.student, status: s.value }));
        const r = await api('/attendance', { method: 'POST', body: { subject, date, records } }); toast(r.message);
      });
    });
    $('#sub').addEventListener('change', load); $('#date').addEventListener('change', load); load();
  }

  async function marks() {
    const subs = (await api('/subjects/mine')).data;
    main().innerHTML = `<header class="bar"><h1>Marks</h1></header>`;
    if (!subs.length) { main().innerHTML += noSubjects; return; }
    main().insertAdjacentHTML('beforeend', `<div class="panel row2">${subjectPicker(subs)}<label>Exam<select id="exam">${Object.entries(EXAMS).map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select></label></div><div id="sheet"></div>`);
    const load = attempt(async () => {
      const subject = $('#sub').value; const exam = $('#exam').value;
      const [roster, existing] = await Promise.all([api(`/subjects/${subject}/students`), api(`/marks?subject=${subject}&exam=${exam}`)]);
      const saved = Object.fromEntries(existing.data.map((x) => [x.student, x]));
      const max = existing.data[0]?.maxScore || 20;
      if (!roster.data.length) { $('#sheet').innerHTML = '<div class="panel empty">No students are enrolled in this subject’s course and semester.</div>'; return; }
      $('#sheet').innerHTML = `<div class="panel"><label style="max-width:200px">Maximum score<input id="max" type="number" min="1" value="${max}"></label></div>
        <div class="table-wrap"><table><thead><tr><th>Roll no</th><th>Student</th><th>Score</th></tr></thead><tbody>${roster.data.map((s) => `<tr><td>${esc(s.rollNo)}</td><td>${esc(s.name)}</td>
        <td><input type="number" min="0" step="0.5" data-student="${s._id}" value="${saved[s._id] ? saved[s._id].score : ''}" aria-label="Score for ${esc(s.name)}"></td></tr>`).join('')}</tbody></table></div>
        <div class="bar" style="margin-top:1rem"><span class="muted small">Leave a score blank to skip that student.</span><button class="btn" id="save">Save marks</button></div>`;
      $('#save').onclick = attempt(async () => {
        const records = [...document.querySelectorAll('[data-student]')].filter((i) => i.value !== '').map((i) => ({ student: i.dataset.student, score: Number(i.value) }));
        if (!records.length) throw new Error('Enter at least one score');
        const r = await api('/marks', { method: 'POST', body: { subject, exam, maxScore: Number($('#max').value), records } }); toast(r.message);
      });
    });
    $('#sub').addEventListener('change', load); $('#exam').addEventListener('change', load); load();
  }

  // ---------- Student: marks ----------
  async function mymarks() {
    const { data } = await api('/marks/me');
    main().innerHTML = `<header class="bar"><h1>My marks</h1></header>` + (data.length
      ? `<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Exam</th><th>Score</th><th>Percent</th></tr></thead><tbody>${data.map((m) => `<tr><td>${esc(m.subject.name)}</td><td>${EXAMS[m.exam]}</td><td>${m.score} / ${m.maxScore}</td><td>${Math.round((m.score / m.maxScore) * 100)}%</td></tr>`).join('')}</tbody></table></div>`
      : '<div class="panel empty">No marks have been published for you yet.</div>');
  }

  // ---------- Notices ----------
  async function notices() {
    const { data } = await api('/notices');
    const staff = me.role !== 'student';
    main().innerHTML = `<header class="bar"><h1>Notices</h1></header>` + (staff ? `<form id="nform" class="panel stack"><h2>Post a notice</h2>
      <label>Title<input name="title" required maxlength="140"></label><label>Message<textarea name="body" required></textarea></label>
      <div class="row2"><label>Audience<select name="audience"><option value="all">Everyone</option><option value="students">Students</option><option value="teachers">Teachers</option></select></label>
      <label>Attachment (PDF or image, 5 MB max)<input name="file" type="file" accept=".pdf,image/png,image/jpeg,image/webp"></label></div>
      <div><button class="btn" type="submit">Post notice</button></div></form>` : '') +
      `<div class="panel">${data.length ? data.map((n) => `<article class="notice"><h2>${esc(n.title)}</h2><div class="muted small">${esc(n.postedBy?.name || 'Unknown')} · ${fmt(n.createdAt)} · ${esc(n.audience)}</div><p>${esc(n.body)}</p>
        ${n.file ? `<a href="${esc(n.file)}" target="_blank" rel="noopener">Open attachment</a>` : ''}
        ${staff && (me.role === 'admin' || n.postedBy?._id === me._id) ? ` <button class="btn danger sm" data-del="${n._id}">Delete</button>` : ''}</article>`).join('') : '<p class="empty">No notices yet.</p>'}</div>`;
    const f = $('#nform');
    if (f) f.addEventListener('submit', attempt(async (ev) => {
      ev.preventDefault();
      const fd = new FormData(f); if (!fd.get('file').size) fd.delete('file');
      await api('/notices', { method: 'POST', form: fd }); toast('Notice posted'); notices();
    }));
    main().querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', attempt(async () => {
      if (!confirm('Delete this notice?')) return;
      await api(`/notices/${b.dataset.del}`, { method: 'DELETE' }); toast('Notice deleted'); notices();
    })));
  }

  // ---------- Profile ----------
  async function profile() {
    me = (await api('/auth/me')).user;
    main().innerHTML = `<header class="bar"><h1>Profile</h1></header>
      <div class="panel profile">${me.photo ? `<img class="avatar" src="${esc(me.photo)}" alt="Your profile photo">` : '<div class="avatar" aria-hidden="true"></div>'}
        <div><h2>${esc(me.name)}</h2><div class="muted">${esc(me.email)}</div>
        <div class="muted small">${esc(me.role)}${me.rollNo ? ` · ${esc(me.rollNo)}` : ''}${me.course ? ` · ${esc(refName(me.course))}` : ''}${me.semester ? ` · semester ${me.semester}` : ''}</div></div></div>
      <form id="pform" class="panel stack"><h2>Profile photo</h2><label>JPG, PNG or WebP, up to 2 MB<input name="photo" type="file" accept="image/png,image/jpeg,image/webp" required></label><div><button class="btn" type="submit">Upload photo</button></div></form>
      <form id="cform" class="panel stack"><h2>Change password</h2>
        <label>Current password<input name="currentPassword" type="password" autocomplete="current-password" required></label>
        <label>New password (8+ characters)<input name="newPassword" type="password" minlength="8" autocomplete="new-password" required></label>
        <div><button class="btn" type="submit">Update password</button></div></form>`;
    $('#pform').addEventListener('submit', attempt(async (ev) => {
      ev.preventDefault(); await api('/auth/photo', { method: 'POST', form: new FormData(ev.target) }); toast('Photo updated'); profile();
    }));
    $('#cform').addEventListener('submit', attempt(async (ev) => {
      ev.preventDefault();
      await api('/auth/password', { method: 'PUT', body: Object.fromEntries(new FormData(ev.target).entries()) }); ev.target.reset(); toast('Password updated');
    }));
  }

  // ---------- Boot ----------
  (async () => {
    if (!token) return showAuth();
    try { me = (await api('/auth/me')).user; await startShell(); } catch { showAuth(); }
  })();
})();
